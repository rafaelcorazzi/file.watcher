﻿using System;
using System.IO;

namespace file.watcher
{
    internal class Program
    {
        static void Main(string[] args)
        {
           

            try
            {
                // Pode ser uma pasta na rede \\FOLDER\XPTO
                var Path  = "C:\\lastros";
                FileSystemWatcher watcher = new FileSystemWatcher();
              
                watcher.Path = Path;
               //Pode incluir subdiretorios da pasta
                //watcher.IncludeSubdirectories = true;
                // Tipos de filtros da notificacao NotifyFilters  
                //enumeration.  
                watcher.NotifyFilter = NotifyFilters.Attributes |
                NotifyFilters.CreationTime |
                NotifyFilters.DirectoryName |
                NotifyFilters.FileName |
                NotifyFilters.LastAccess |
                NotifyFilters.LastWrite |
                NotifyFilters.Security |
                NotifyFilters.Size;
                // Filtros de quais tipos de arquivo voce quer vizualizar
                watcher.Filter = "*.*";
                // Disparador dos enventos
                watcher.Changed += new FileSystemEventHandler(OnChanged);
                watcher.Created += new FileSystemEventHandler(OnChanged);
                watcher.Deleted += new FileSystemEventHandler(OnChanged);
                watcher.Renamed += new RenamedEventHandler(OnRenamed);
                //Start monitoring.  
                watcher.EnableRaisingEvents = true;
            
            
         
                Console.WriteLine("Pressione \'q\' para sair do programa.");
                Console.WriteLine();
                
                while (Console.Read() != 'q') ;
            }
            catch (IOException e)
            {
                Console.WriteLine("A Exception Occurred :" + e);
            }
            catch (Exception oe)
            {
                Console.WriteLine("An Exception Occurred :" + oe);
            }
        }

        public static void OnChanged(object source, FileSystemEventArgs e)
        {
           
            Console.WriteLine("{0}, {1} {2}", e.Name, e.FullPath, e.ChangeType);
        }
        public static void OnRenamed(object source, RenamedEventArgs e)
        {
           
            Console.WriteLine(" {0} arquivo renomeado para {1}", e.OldFullPath, e.FullPath);
        }
    }

}

